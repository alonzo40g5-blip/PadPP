package com.npp.mobile

import android.graphics.Typeface
import android.text.Editable
import android.text.Spannable
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import java.util.regex.Pattern

/**
 * Regex-based highlighter in the spirit of Notepad++'s default styler:
 * keywords blue+bold, comments green, strings gray, numbers orange,
 * preprocessor/meta brown. Ranges are claimed in priority order so a
 * keyword inside a string stays gray, etc.
 */
class Highlighter(
    val kw: Int, val comment: Int, val str: Int, val num: Int,
    val meta: Int, val tag: Int, val attr: Int, val type: Int
) {

    /** Marker subclasses so we only ever remove our own spans. */
    class HlColorSpan(color: Int) : ForegroundColorSpan(color)
    class HlBoldSpan : StyleSpan(Typeface.BOLD)

    companion object {
        const val MAX_HIGHLIGHT_CHARS = 250_000
        private val NO_HIGHLIGHT = setOf("plaintext", "csv", "nfo")

        private val NUMBER: Pattern =
            Pattern.compile("\\b(0[xX][0-9a-fA-F_]+|\\d[\\d_]*(\\.\\d+)?([eE][+-]?\\d+)?)[fFdDlLuU]*\\b")
        private val ENTITY: Pattern = Pattern.compile("&#?\\w+;")
        private val MD_HEADER: Pattern = Pattern.compile("(?m)^#{1,6}[ \\t].*$")
        private val MD_CODE: Pattern = Pattern.compile("`[^`\\n]+`")
        private val MD_QUOTE: Pattern = Pattern.compile("(?m)^>.*$")
        private val CSS_PROP: Pattern = Pattern.compile("(?m)([-A-Za-z]+)\\s*(?=:)")
        private val YAML_KEY: Pattern = Pattern.compile("(?m)^[ \\t]*-?[ \\t]*([\\w.\\-]+)[ \\t]*(?=:)")
        private val PROPS_KEY: Pattern = Pattern.compile("(?m)^[ \\t]*([\\w.\\-]+)[ \\t]*(?==)")
        private val SHELL_VAR: Pattern = Pattern.compile("\\$(\\{[^}\\n]*\\}|\\([^)\\n]*\\)|\\w+)")
        private val PREPROC: Pattern = Pattern.compile("(?m)^[ \\t]*#\\s*\\w+[^\\n]*")
        private val XML_TAGNAME: Pattern = Pattern.compile("</?\\s*([A-Za-z][\\w:.\\-]*)")
        private val XML_ATTR: Pattern = Pattern.compile("\\b([A-Za-z_:][\\w:.\\-]*)\\s*(?==)")
        private val XML_META: Pattern = Pattern.compile("<[!?][^>]*>")
        private val SERVER_BLOCK: Pattern = Pattern.compile("<%[\\s\\S]*?%>")
        private val TRIPLE: Pattern =
            Pattern.compile("\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''")
        private val SECTION_HEADER: Pattern = Pattern.compile("(?m)^\\[[^\\]\\n]*\\][ \\t]*$")

        // diff
        private val DIFF_FILE: Pattern = Pattern.compile("(?m)^(diff |index |\\+\\+\\+ |--- ).*$")
        private val DIFF_HUNK: Pattern = Pattern.compile("(?m)^@@[^\\n]*")
        private val DIFF_ADD: Pattern = Pattern.compile("(?m)^\\+[^\\n]*")
        private val DIFF_DEL: Pattern = Pattern.compile("(?m)^-[^\\n]*")

        // TeX / LaTeX
        private val TEX_CMD: Pattern = Pattern.compile("\\\\[A-Za-z@]+")
        private val TEX_MATH: Pattern = Pattern.compile("\\$[^$\\n]{1,200}\\$")

        // logs / terminals
        private val ANSI_ESC: Pattern = Pattern.compile("\\u001B\\[[0-9;]*[A-Za-z]")
        private val ERR_LINE: Pattern = Pattern.compile("(?im)^.*\\b(error|fatal|fail(ed|ure)?)\\b.*$")
        private val WARN_LINE: Pattern = Pattern.compile("(?im)^.*\\bwarn(ing)?\\b.*$")

        // Internal Search results
        private val SEARCH_HEAD: Pattern = Pattern.compile("(?m)^Search .*$")
        private val SEARCH_FILE: Pattern = Pattern.compile("(?m)^\\S.*\\(\\d+ hits?\\).*$")
        private val SEARCH_LINE: Pattern = Pattern.compile("(?m)^[ \\t]+Line \\d+:")

        // HEX record formats
        private val HEX_PREFIX: Pattern = Pattern.compile("(?m)^[:%S]")
        private val HEX_DATA: Pattern = Pattern.compile("(?m)[0-9A-Fa-f]{4,}")

        // misc extras
        private val OBJC_AT: Pattern = Pattern.compile("@[A-Za-z_]\\w*")
        private val MAKE_TARGET: Pattern = Pattern.compile("(?m)^([A-Za-z0-9_.\\-]+)\\s*:")
        private val SPICE_STAR: Pattern = Pattern.compile("(?m)^\\*[^\\n]*")
        private val T2T_HEADER: Pattern = Pattern.compile("(?m)^={1,6}[^=\\n]+={1,6}[ \\t]*$")
        private val CSS_HEXCOLOR: Pattern = Pattern.compile("#[0-9a-fA-F]{3,8}\\b")
        private val CSS_AT: Pattern = Pattern.compile("@[-\\w]+")
    }

    private val keywordCache = HashMap<String, Pattern>()

    fun clear(e: Editable) {
        for (s in e.getSpans(0, e.length, HlColorSpan::class.java)) e.removeSpan(s)
        for (s in e.getSpans(0, e.length, HlBoldSpan::class.java)) e.removeSpan(s)
    }

    fun highlight(e: Editable, lang: Languages.Lang) {
        clear(e)
        val len = e.length
        if (len == 0 || len > MAX_HIGHLIGHT_CHARS) return
        if (lang.key in NO_HIGHLIGHT) return

        val claimed = BooleanArray(len)
        val text = e.toString()

        // ---- fully special formats ----
        when (lang.key) {
            "markdown" -> {
                apply(e, text, claimed, MD_HEADER, tag, bold = true)
                apply(e, text, claimed, MD_CODE, str)
                apply(e, text, claimed, MD_QUOTE, comment)
                apply(e, text, claimed, NUMBER, num)
                return
            }
            "diff" -> {
                apply(e, text, claimed, DIFF_FILE, meta, bold = true)
                apply(e, text, claimed, DIFF_HUNK, kw, bold = true)
                apply(e, text, claimed, DIFF_ADD, comment)
                apply(e, text, claimed, DIFF_DEL, attr)
                return
            }
            "errorlist" -> {
                apply(e, text, claimed, ANSI_ESC, meta)
                apply(e, text, claimed, ERR_LINE, attr)
                apply(e, text, claimed, WARN_LINE, num)
                return
            }
            "escapeseq" -> {
                apply(e, text, claimed, ANSI_ESC, meta, bold = true)
                apply(e, text, claimed, NUMBER, num)
                return
            }
            "searchresult" -> {
                apply(e, text, claimed, SEARCH_HEAD, kw, bold = true)
                apply(e, text, claimed, SEARCH_FILE, meta)
                apply(e, text, claimed, SEARCH_LINE, comment)
                return
            }
            "intelhex", "srecord", "tekhex" -> {
                apply(e, text, claimed, HEX_PREFIX, kw, bold = true)
                apply(e, text, claimed, HEX_DATA, num)
                return
            }
            "txt2tags" -> {
                apply(e, text, claimed, T2T_HEADER, tag, bold = true)
                apply(e, text, claimed, linePattern("%"), comment)
                apply(e, text, claimed, MD_CODE, str)
                return
            }
        }

        // ---- markup family (HTML, XML, ASP, JSP) ----
        if (lang.markup) {
            for ((o, c) in lang.blockComments) apply(e, text, claimed, blockPattern(o, c), comment)
            apply(e, text, claimed, SERVER_BLOCK, meta)
            apply(e, text, claimed, XML_META, meta)
            for (d in lang.stringDelims) apply(e, text, claimed, stringPattern(d), str)
            apply(e, text, claimed, XML_TAGNAME, tag, bold = true, group = 1)
            apply(e, text, claimed, XML_ATTR, attr, group = 1)
            apply(e, text, claimed, ENTITY, type)
            return
        }

        // ---- generic path ----
        // 1) strings (triple-quoted first, so python/gdscript docstrings win)
        if (lang.tripleQuotes) apply(e, text, claimed, TRIPLE, str)
        for (d in lang.stringDelims) apply(e, text, claimed, stringPattern(d), str)

        // 2) comments
        for ((o, c) in lang.blockComments) apply(e, text, claimed, blockPattern(o, c), comment)
        for (lc in lang.lineComments) apply(e, text, claimed, linePattern(lc), comment)

        // 3) language extras
        if (lang.preprocessor) apply(e, text, claimed, PREPROC, meta)
        if (lang.hashVars) apply(e, text, claimed, SHELL_VAR, type)
        when (lang.key) {
            "css" -> {
                apply(e, text, claimed, CSS_AT, meta)
                apply(e, text, claimed, CSS_PROP, kw, group = 1)
                apply(e, text, claimed, CSS_HEXCOLOR, num)
            }
            "yaml" -> apply(e, text, claimed, YAML_KEY, kw, group = 1)
            "ini", "toml", "registry", "inno" -> {
                apply(e, text, claimed, SECTION_HEADER, meta, bold = true)
                apply(e, text, claimed, PROPS_KEY, kw, group = 1)
            }
            "properties" -> apply(e, text, claimed, PROPS_KEY, kw, group = 1)
            "makefile" -> apply(e, text, claimed, MAKE_TARGET, kw, bold = true, group = 1)
            "objc" -> apply(e, text, claimed, OBJC_AT, kw, bold = true)
            "spice" -> apply(e, text, claimed, SPICE_STAR, comment)
            "latex", "tex" -> {
                apply(e, text, claimed, TEX_CMD, kw, bold = true)
                apply(e, text, claimed, TEX_MATH, str)
            }
        }

        // 4) numbers
        apply(e, text, claimed, NUMBER, num)

        // 5) keywords
        if (lang.keywords.isNotEmpty()) {
            apply(e, text, claimed, keywordPattern(lang), kw, bold = true)
        }
    }

    private fun keywordPattern(lang: Languages.Lang): Pattern =
        keywordCache.getOrPut(lang.key) {
            val body = lang.keywords.joinToString("|") { Pattern.quote(it) }
            val flags = if (lang.caseInsensitiveKeywords) Pattern.CASE_INSENSITIVE else 0
            Pattern.compile("\\b(?:$body)\\b", flags)
        }

    private fun stringPattern(delim: Char): Pattern {
        val d = Pattern.quote(delim.toString())
        return if (delim == '`')
            Pattern.compile("$d[\\s\\S]*?$d")                       // template literals span lines
        else
            Pattern.compile("$d(?:\\\\.|[^\\\\\\n$d])*$d")
    }

    private fun blockPattern(open: String, close: String): Pattern =
        Pattern.compile(Pattern.quote(open) + "[\\s\\S]*?" + Pattern.quote(close))

    private fun linePattern(lc: String): Pattern =
        Pattern.compile("(?m)" + Pattern.quote(lc) + "[^\\n]*")

    private fun apply(
        e: Editable, text: String, claimed: BooleanArray,
        p: Pattern, color: Int, bold: Boolean = false, group: Int = 0
    ) {
        val m = p.matcher(text)
        while (m.find()) {
            val s = m.start(group)
            val en = m.end(group)
            if (s < 0 || en <= s) continue
            var free = true
            var i = s
            while (i < en) { if (claimed[i]) { free = false; break }; i++ }
            if (!free) continue
            e.setSpan(HlColorSpan(color), s, en, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (bold) e.setSpan(HlBoldSpan(), s, en, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            java.util.Arrays.fill(claimed, s, en, true)
        }
    }
}
