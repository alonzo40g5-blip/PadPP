package com.npp.mobile

/**
 * Language table mirroring the official Notepad++ built-in list
 * (npp-user-manual.org/docs/programing-languages/ — 93 languages),
 * plus Kotlin, Markdown, Gradle/Groovy and CSV on top.
 * Any unknown extension falls back to plain text, so every file opens.
 */
object Languages {

    class Lang(
        val key: String,
        val label: String,          // status-bar long name, N++ style
        val menu: String,           // Language picker name
        val exts: List<String>,
        val keywords: Set<String> = emptySet(),
        val caseInsensitiveKeywords: Boolean = false,
        val lineComments: List<String> = emptyList(),
        val blockComments: List<Pair<String, String>> = emptyList(),
        val stringDelims: List<Char> = listOf('"', '\''),
        val tripleQuotes: Boolean = false,
        val markup: Boolean = false,
        val preprocessor: Boolean = false,   // C-style ^#... lines
        val hashVars: Boolean = false        // $VAR / ${VAR} / $(VAR)
    )

    private val CLIKE = setOf(
        "if", "else", "for", "while", "do", "switch", "case", "default", "break",
        "continue", "return", "true", "false", "null", "new", "this", "static",
        "void", "class", "public", "private", "protected", "try", "catch", "finally", "throw"
    )

    val ALL: List<Lang> = listOf(
        Lang("plaintext", "Normal text file", "Normal Text", listOf("txt", "text", "log")),

        // ---------- the official Notepad++ 93 ----------
        Lang("actionscript", "ActionScript file", "ActionScript", listOf("as"),
            keywords = CLIKE + setOf("function", "var", "import", "package", "extends", "override", "trace"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("ada", "Ada source file", "Ada", listOf("ada", "adb", "ads"),
            keywords = setOf("procedure", "function", "begin", "end", "is", "if", "then", "else",
                "elsif", "loop", "for", "while", "return", "package", "body", "with", "use",
                "type", "record", "null", "declare", "when", "case", "others", "exception", "raise"),
            caseInsensitiveKeywords = true, lineComments = listOf("--")),

        Lang("asn1", "Abstract Syntax Notation One file", "ASN.1", listOf("asn", "asn1"),
            keywords = setOf("DEFINITIONS", "BEGIN", "END", "SEQUENCE", "SET", "CHOICE", "OF",
                "INTEGER", "BOOLEAN", "OPTIONAL", "DEFAULT", "IMPLICIT", "EXPLICIT", "IMPORTS", "EXPORTS"),
            lineComments = listOf("--")),

        Lang("asp", "Active Server Pages script file", "ASP", listOf("asp", "asa"),
            markup = true, blockComments = listOf("<!--" to "-->")),

        Lang("assembly", "Assembly language source file", "Assembly", listOf("asm", "s", "inc", "nasm"),
            keywords = setOf("mov", "add", "sub", "mul", "div", "push", "pop", "call", "ret",
                "jmp", "cmp", "je", "jne", "jz", "jnz", "jg", "jl", "lea", "int", "nop", "xor",
                "and", "or", "not", "shl", "shr", "inc", "dec", "db", "dw", "dd", "dq",
                "section", "global", "extern", "equ", "org"),
            caseInsensitiveKeywords = true, lineComments = listOf(";")),

        Lang("autoit", "AutoIt script file", "AutoIt", listOf("au3"),
            keywords = setOf("Func", "EndFunc", "If", "Then", "Else", "ElseIf", "EndIf",
                "While", "WEnd", "For", "Next", "Do", "Until", "Switch", "EndSwitch",
                "Local", "Global", "Dim", "Const", "Return", "True", "False", "Exit"),
            caseInsensitiveKeywords = true, lineComments = listOf(";"),
            blockComments = listOf("#cs" to "#ce")),

        Lang("avisynth", "AviSynth script file", "AviSynth", listOf("avs", "avsi"),
            keywords = setOf("function", "return", "last", "true", "false", "AviSource",
                "DirectShowSource", "Trim", "Crop", "ConvertToRGB32"),
            caseInsensitiveKeywords = true, lineComments = listOf("#"),
            blockComments = listOf("/*" to "*/")),

        Lang("baanc", "BaanC source file", "BaanC", listOf("bc", "cln"),
            keywords = setOf("function", "if", "then", "else", "endif", "while", "endwhile",
                "for", "endfor", "case", "endcase", "on", "domain", "table", "select",
                "from", "where", "selectdo", "endselect", "long", "string", "double"),
            lineComments = listOf("|")),

        Lang("batch", "Batch file", "Batch", listOf("bat", "cmd"),
            keywords = setOf("echo", "set", "if", "else", "exist", "for", "in", "do", "goto",
                "call", "exit", "rem", "not", "defined", "errorlevel", "pause", "setlocal",
                "endlocal", "shift", "start", "cd", "copy", "del", "md", "rd", "off", "on"),
            caseInsensitiveKeywords = true, lineComments = listOf("::"), hashVars = true),

        Lang("blitzbasic", "BlitzBasic file", "BlitzBasic", listOf("bb"),
            keywords = setOf("Function", "End", "If", "Then", "Else", "ElseIf", "EndIf",
                "For", "Next", "While", "Wend", "Repeat", "Until", "Return", "Local",
                "Global", "Const", "Dim", "Type", "Field", "True", "False", "Print"),
            caseInsensitiveKeywords = true, lineComments = listOf(";")),

        Lang("c", "C source file", "C", listOf("c", "h"),
            keywords = setOf("auto", "break", "case", "char", "const", "continue", "default",
                "do", "double", "else", "enum", "extern", "float", "for", "goto", "if",
                "inline", "int", "long", "register", "restrict", "return", "short", "signed",
                "sizeof", "static", "struct", "switch", "typedef", "union", "unsigned",
                "void", "volatile", "while"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/"), preprocessor = true),

        Lang("csharp", "C# source file", "C#", listOf("cs"),
            keywords = CLIKE + setOf("abstract", "as", "base", "bool", "byte", "checked",
                "const", "decimal", "delegate", "double", "enum", "event", "explicit",
                "extern", "fixed", "float", "foreach", "goto", "implicit", "in", "int",
                "interface", "internal", "is", "lock", "long", "namespace", "object",
                "operator", "out", "override", "params", "readonly", "ref", "sbyte",
                "sealed", "short", "sizeof", "string", "struct", "typeof", "uint", "ulong",
                "unsafe", "ushort", "using", "virtual", "var", "async", "await"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("cpp", "C++ source file", "C++", listOf("cpp", "cc", "cxx", "hpp", "hh", "hxx"),
            keywords = setOf("auto", "bool", "break", "case", "catch", "char", "class",
                "const", "constexpr", "continue", "default", "delete", "do", "double",
                "else", "enum", "explicit", "extern", "false", "float", "for", "friend",
                "goto", "if", "inline", "int", "long", "namespace", "new", "nullptr",
                "operator", "private", "protected", "public", "return", "short", "signed",
                "sizeof", "static", "struct", "switch", "template", "this", "throw",
                "true", "try", "typedef", "typename", "union", "unsigned", "using",
                "virtual", "void", "volatile", "while"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/"), preprocessor = true),

        Lang("caml", "CAML source file", "CAML", listOf("ml", "mli"),
            keywords = setOf("let", "in", "if", "then", "else", "match", "with", "fun",
                "function", "type", "rec", "module", "open", "begin", "end", "and", "or",
                "not", "true", "false", "mutable", "ref", "raise", "try", "exception"),
            blockComments = listOf("(*" to "*)")),

        Lang("cmake", "CMake file", "CMake", listOf("cmake"),
            keywords = setOf("project", "cmake_minimum_required", "add_executable",
                "add_library", "add_subdirectory", "target_link_libraries",
                "target_include_directories", "set", "if", "else", "elseif", "endif",
                "foreach", "endforeach", "function", "endfunction", "macro", "endmacro",
                "include", "message", "option", "find_package", "install"),
            caseInsensitiveKeywords = true, lineComments = listOf("#"), hashVars = true),

        Lang("cobol", "COBOL source file", "COBOL", listOf("cbl", "cob", "cpy"),
            keywords = setOf("identification", "division", "program-id", "environment",
                "data", "procedure", "section", "working-storage", "perform", "move",
                "to", "if", "else", "end-if", "display", "accept", "stop", "run", "pic",
                "picture", "value", "compute", "add", "subtract", "multiply", "divide",
                "open", "close", "read", "write", "until", "varying"),
            caseInsensitiveKeywords = true, lineComments = listOf("*>")),

        Lang("coffeescript", "CoffeeScript file", "CoffeeScript", listOf("coffee", "litcoffee"),
            keywords = setOf("if", "else", "unless", "for", "while", "until", "then",
                "return", "class", "extends", "new", "true", "false", "null", "undefined",
                "and", "or", "not", "is", "isnt", "this", "switch", "when", "try", "catch",
                "finally", "throw", "in", "of", "yes", "no", "on", "off"),
            lineComments = listOf("#"), blockComments = listOf("###" to "###")),

        Lang("csound", "Csound file", "Csound", listOf("orc", "sco", "csd"),
            keywords = setOf("instr", "endin", "opcode", "endop", "sr", "kr", "ksmps",
                "nchnls", "0dbfs", "out", "outs", "oscil", "oscili", "linen", "linseg", "init"),
            lineComments = listOf(";"), blockComments = listOf("/*" to "*/")),

        Lang("css", "Cascading Style Sheets File", "CSS", listOf("css", "scss", "less", "sass"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("d", "D programming language file", "D", listOf("d", "di"),
            keywords = CLIKE + setOf("void", "int", "char", "bool", "foreach", "import",
                "module", "struct", "enum", "immutable", "const", "auto", "final",
                "override", "template", "mixin", "alias", "ubyte", "ulong", "uint"),
            lineComments = listOf("//"),
            blockComments = listOf("/*" to "*/", "/+" to "+/")),

        Lang("diff", "Diff file", "Diff", listOf("diff", "patch"),
            stringDelims = emptyList()),

        Lang("erlang", "Erlang source file", "Erlang", listOf("erl", "hrl"),
            keywords = setOf("module", "export", "import", "fun", "case", "of", "end",
                "if", "when", "receive", "after", "begin", "try", "catch", "throw",
                "true", "false", "andalso", "orelse", "not", "div", "rem", "spawn"),
            lineComments = listOf("%")),

        Lang("errorlist", "Error list / build log", "ErrorList", listOf("err"),
            stringDelims = emptyList()),

        Lang("escapeseq", "ANSI escape sequence file", "EscapeSequence (ANSI)", listOf("ans", "ansi"),
            stringDelims = emptyList()),

        Lang("escript", "ESCRIPT source file", "ESCRIPT", listOf("em"),
            keywords = setOf("function", "endfunction", "if", "else", "elseif", "endif",
                "while", "endwhile", "for", "endfor", "return", "var", "const", "case"),
            caseInsensitiveKeywords = true,
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("forth", "Forth source file", "Forth", listOf("forth", "4th", "fth"),
            keywords = setOf("dup", "drop", "swap", "over", "rot", "if", "then", "else",
                "begin", "until", "while", "repeat", "do", "loop", "variable", "constant",
                "create", "allot", "emit", "cr"),
            caseInsensitiveKeywords = true, lineComments = listOf("\\")),

        Lang("fortranfixed", "Fortran fixed form source file", "Fortran (fixed form)",
            listOf("f", "for", "f77"),
            keywords = setOf("program", "end", "subroutine", "function", "if", "then",
                "else", "endif", "do", "continue", "call", "return", "integer", "real",
                "character", "dimension", "implicit", "none", "write", "read", "format",
                "stop", "common", "data", "parameter", "goto"),
            caseInsensitiveKeywords = true, lineComments = listOf("!"), stringDelims = listOf('\'', '"')),

        Lang("fortranfree", "Fortran free form source file", "Fortran (free form)",
            listOf("f90", "f95", "f03", "f08"),
            keywords = setOf("program", "end", "subroutine", "function", "module", "use",
                "contains", "if", "then", "else", "endif", "do", "enddo", "call", "return",
                "integer", "real", "character", "logical", "allocatable", "allocate",
                "implicit", "none", "write", "read", "print", "intent", "in", "out"),
            caseInsensitiveKeywords = true, lineComments = listOf("!"), stringDelims = listOf('\'', '"')),

        Lang("freebasic", "FreeBasic source file", "FreeBasic", listOf("bas", "bi"),
            keywords = setOf("dim", "as", "integer", "string", "double", "if", "then",
                "else", "elseif", "end", "sub", "function", "return", "for", "next",
                "while", "wend", "do", "loop", "select", "case", "print", "true", "false",
                "byval", "byref", "declare", "type", "shared"),
            caseInsensitiveKeywords = true, lineComments = listOf("'"),
            blockComments = listOf("/'" to "'/")),

        Lang("gdscript", "GDScript file", "GDScript", listOf("gd"),
            keywords = setOf("func", "var", "const", "if", "elif", "else", "for", "while",
                "match", "return", "class", "class_name", "extends", "signal", "export",
                "onready", "pass", "true", "false", "null", "self", "tool", "await",
                "and", "or", "not", "in", "is", "as", "breakpoint"),
            lineComments = listOf("#"), tripleQuotes = true),

        Lang("go", "Go source file", "Go", listOf("go"),
            keywords = setOf("break", "case", "chan", "const", "continue", "default",
                "defer", "else", "fallthrough", "for", "func", "go", "goto", "if",
                "import", "interface", "map", "package", "range", "return", "select",
                "struct", "switch", "type", "var", "nil", "true", "false", "make",
                "new", "append", "len", "cap"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/"),
            stringDelims = listOf('"', '\'', '`')),

        Lang("gui4cli", "Gui4Cli file", "Gui4Cli", listOf("gui", "gc"),
            keywords = setOf("xOnLoad", "xOnOpen", "xButton", "xTextIn", "xCheckbox",
                "Run", "Quit", "If", "EndIf", "SetVar", "Goto"),
            caseInsensitiveKeywords = true, lineComments = listOf("//")),

        Lang("haskell", "Haskell source file", "Haskell", listOf("hs", "lhs"),
            keywords = setOf("module", "import", "where", "let", "in", "do", "case", "of",
                "if", "then", "else", "data", "type", "newtype", "class", "instance",
                "deriving", "otherwise", "True", "False", "Just", "Nothing", "return", "IO"),
            lineComments = listOf("--"), blockComments = listOf("{-" to "-}")),

        Lang("hollywood", "Hollywood script file", "Hollywood", listOf("hws"),
            keywords = setOf("Function", "EndFunction", "If", "Else", "ElseIf", "EndIf",
                "For", "Next", "While", "Wend", "Repeat", "Until", "Local", "Global",
                "Return", "True", "False", "Switch", "Case", "EndSwitch", "Dim"),
            caseInsensitiveKeywords = true, lineComments = listOf(";"),
            blockComments = listOf("/*" to "*/")),

        Lang("html", "Hyper Text Markup Language file", "HTML",
            listOf("html", "htm", "xhtml", "vue", "svelte"),
            markup = true, blockComments = listOf("<!--" to "-->")),

        Lang("ini", "MS ini file", "ini", listOf("ini", "inf", "cfg", "conf", "url"),
            lineComments = listOf(";", "#")),

        Lang("inno", "Inno Setup script file", "Inno Setup", listOf("iss", "isl"),
            keywords = setOf("begin", "end", "procedure", "function", "if", "then",
                "else", "var", "const", "uses", "Setup", "Files", "Icons", "Run",
                "Registry", "Code", "Tasks", "Languages"),
            caseInsensitiveKeywords = true, lineComments = listOf(";", "//")),

        Lang("intelhex", "Intel HEX file", "Intel HEX", listOf("hex", "ihx"),
            stringDelims = emptyList()),

        Lang("searchresult", "Search result", "Internal Search", listOf("results"),
            stringDelims = emptyList()),

        Lang("java", "Java source file", "Java", listOf("java"),
            keywords = CLIKE + setOf("abstract", "assert", "boolean", "byte", "char",
                "const", "double", "enum", "extends", "final", "float", "goto",
                "implements", "import", "instanceof", "int", "interface", "long",
                "native", "package", "short", "strictfp", "super", "synchronized",
                "throws", "transient", "volatile", "var", "record"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("javascript", "JavaScript file", "JavaScript", listOf("js", "mjs", "cjs", "jsx"),
            keywords = CLIKE + setOf("async", "await", "const", "debugger", "delete",
                "export", "extends", "function", "import", "in", "instanceof", "let",
                "of", "super", "typeof", "undefined", "var", "with", "yield"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/"),
            stringDelims = listOf('"', '\'', '`')),

        Lang("json", "JSON file", "json", listOf("json", "geojson", "webmanifest"),
            keywords = setOf("true", "false", "null"), stringDelims = listOf('"')),

        Lang("json5", "JSON5 file", "json5", listOf("json5"),
            keywords = setOf("true", "false", "null", "Infinity", "NaN"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("jsp", "JavaServer Pages script file", "JSP", listOf("jsp", "jspx"),
            markup = true, blockComments = listOf("<!--" to "-->")),

        Lang("kixtart", "KiXtart file", "KiXtart", listOf("kix"),
            keywords = setOf("if", "else", "endif", "select", "case", "endselect", "do",
                "until", "while", "loop", "for", "next", "gosub", "return", "function",
                "endfunction", "exit", "run", "shell", "goto", "use", "dim", "global"),
            caseInsensitiveKeywords = true, lineComments = listOf(";"), hashVars = true),

        Lang("latex", "LaTeX file", "LaTeX", listOf("tex", "ltx", "bib"),
            lineComments = listOf("%"), stringDelims = emptyList()),

        Lang("lisp", "Lisp source file", "Lisp", listOf("lisp", "lsp", "el", "cl"),
            keywords = setOf("defun", "defvar", "defmacro", "defparameter", "let", "let*",
                "lambda", "if", "cond", "when", "unless", "car", "cdr", "cons", "list",
                "setq", "setf", "quote", "progn", "loop", "t", "nil", "eq", "equal"),
            lineComments = listOf(";")),

        Lang("lua", "Lua source file", "Lua", listOf("lua"),
            keywords = setOf("and", "break", "do", "else", "elseif", "end", "false",
                "for", "function", "goto", "if", "in", "local", "nil", "not", "or",
                "repeat", "return", "then", "true", "until", "while", "self"),
            lineComments = listOf("--"), blockComments = listOf("--[[" to "]]")),

        Lang("makefile", "Makefile", "Makefile", listOf("mk", "mak"),
            keywords = setOf("include", "ifeq", "ifneq", "ifdef", "ifndef", "endif",
                "define", "endef", "export", "unexport", "override", "PHONY"),
            lineComments = listOf("#"), hashVars = true, stringDelims = emptyList()),

        Lang("matlab", "MATLAB file", "MATLAB", listOf("m"),
            keywords = setOf("function", "end", "if", "elseif", "else", "for", "while",
                "break", "continue", "return", "switch", "case", "otherwise", "true",
                "false", "global", "persistent", "try", "catch", "classdef", "properties",
                "methods"),
            lineComments = listOf("%"), blockComments = listOf("%{" to "%}"),
            stringDelims = listOf('\'', '"')),

        Lang("mmixal", "MMIXAL file", "MMIXAL", listOf("mms"),
            keywords = setOf("LOC", "GREG", "BYTE", "WYDE", "TETRA", "OCTA", "IS", "SET",
                "LDA", "LDB", "LDO", "STB", "STO", "TRAP", "JMP", "CMP", "ADD", "SUB"),
            lineComments = listOf("%")),

        Lang("mssql", "Microsoft Transact-SQL file", "mssql", listOf("tsql"),
            keywords = setOf("select", "from", "where", "insert", "into", "values",
                "update", "set", "delete", "create", "table", "drop", "alter", "index",
                "view", "join", "inner", "left", "right", "on", "group", "by", "order",
                "having", "distinct", "as", "and", "or", "not", "null", "go", "begin",
                "end", "declare", "exec", "print", "if", "else", "while", "cursor",
                "fetch", "procedure", "trigger", "int", "varchar", "nvarchar", "datetime"),
            caseInsensitiveKeywords = true,
            lineComments = listOf("--"), blockComments = listOf("/*" to "*/"),
            hashVars = true),

        Lang("nfo", "MS-DOS Style / ASCII art file", "NFO", listOf("nfo", "diz"),
            stringDelims = emptyList()),

        Lang("nim", "Nim source file", "Nim", listOf("nim", "nims"),
            keywords = setOf("proc", "func", "method", "var", "let", "const", "if",
                "elif", "else", "for", "while", "case", "of", "when", "import", "include",
                "type", "object", "return", "echo", "true", "false", "nil", "discard",
                "template", "macro", "iterator", "yield", "ref", "ptr"),
            lineComments = listOf("#"), blockComments = listOf("#[" to "]#")),

        Lang("nncron", "Nncrontab file", "Nncrontab", listOf("tab", "spf"),
            keywords = setOf("Rule", "Time", "Action", "NoActive", "Again", "StartOnce",
                "WatchDir", "Days", "Months"),
            caseInsensitiveKeywords = true, lineComments = listOf("#")),

        Lang("nsis", "Nullsoft Scriptable Install System script file", "NSIS", listOf("nsi", "nsh"),
            keywords = setOf("Section", "SectionEnd", "Function", "FunctionEnd", "Name",
                "OutFile", "InstallDir", "Page", "SetOutPath", "File", "WriteUninstaller",
                "Exec", "ExecWait", "MessageBox", "Var", "Goto", "Return", "Call",
                "StrCpy", "StrCmp", "DetailPrint", "Delete", "RMDir"),
            caseInsensitiveKeywords = true, lineComments = listOf(";", "#"), hashVars = true),

        Lang("objc", "Objective-C source file", "Objective-C", listOf("mm"),
            keywords = setOf("interface", "implementation", "property", "synthesize",
                "protocol", "selector", "id", "self", "super", "nil", "YES", "NO",
                "if", "else", "for", "while", "do", "switch", "case", "return", "break",
                "continue", "static", "const", "void", "int", "char", "float", "double",
                "typedef", "struct", "enum"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/"),
            preprocessor = true),

        Lang("oscript", "OScript source file", "OScript", listOf("oscript", "os"),
            keywords = setOf("function", "end", "if", "else", "elseif", "for", "while",
                "return", "object", "inherits", "override", "public", "private",
                "Integer", "String", "Boolean", "true", "false", "undefined"),
            caseInsensitiveKeywords = true,
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("pascal", "Pascal source file", "Pascal", listOf("pas", "pp", "p", "lpr", "dpr"),
            keywords = setOf("program", "unit", "uses", "interface", "implementation",
                "begin", "end", "procedure", "function", "var", "const", "type", "record",
                "array", "of", "if", "then", "else", "for", "to", "downto", "do", "while",
                "repeat", "until", "case", "with", "nil", "true", "false", "class",
                "object", "inherited", "constructor", "destructor", "not", "and", "or", "div", "mod"),
            caseInsensitiveKeywords = true, lineComments = listOf("//"),
            blockComments = listOf("{" to "}", "(*" to "*)"), stringDelims = listOf('\'')),

        Lang("perl", "Perl source file", "Perl", listOf("pl", "pm", "plx", "t"),
            keywords = setOf("my", "our", "local", "sub", "use", "require", "if", "elsif",
                "else", "unless", "while", "until", "for", "foreach", "return", "last",
                "next", "redo", "print", "say", "chomp", "defined", "undef", "ne", "eq",
                "lt", "gt", "le", "ge", "and", "or", "not", "qw", "die", "do", "package", "bless"),
            lineComments = listOf("#"), hashVars = true),

        Lang("php", "PHP Hypertext Preprocessor file", "PHP", listOf("php", "phtml"),
            keywords = setOf("abstract", "and", "array", "as", "break", "case", "catch",
                "class", "const", "continue", "declare", "default", "do", "echo", "else",
                "elseif", "extends", "final", "finally", "fn", "for", "foreach",
                "function", "global", "if", "implements", "include", "instanceof",
                "interface", "isset", "namespace", "new", "null", "or", "print",
                "private", "protected", "public", "require", "return", "static",
                "switch", "throw", "trait", "true", "false", "try", "unset", "use", "while"),
            lineComments = listOf("//", "#"), blockComments = listOf("/*" to "*/"),
            hashVars = true),

        Lang("postscript", "PostScript file", "PostScript", listOf("ps", "eps"),
            keywords = setOf("def", "dict", "begin", "end", "moveto", "lineto", "curveto",
                "stroke", "fill", "show", "showpage", "gsave", "grestore", "translate",
                "scale", "rotate", "setgray", "setrgbcolor", "newpath", "closepath",
                "findfont", "scalefont", "setfont"),
            lineComments = listOf("%"), stringDelims = emptyList()),

        Lang("powershell", "Windows PowerShell script file", "PowerShell",
            listOf("ps1", "psm1", "psd1"),
            keywords = setOf("function", "param", "if", "elseif", "else", "foreach",
                "for", "while", "do", "switch", "return", "try", "catch", "finally",
                "throw", "begin", "process", "end", "break", "continue", "in", "filter",
                "workflow", "class", "enum", "using", "not", "and", "or", "eq", "ne"),
            caseInsensitiveKeywords = true, lineComments = listOf("#"),
            blockComments = listOf("<#" to "#>"), hashVars = true),

        Lang("properties", "Properties file", "Properties file",
            listOf("properties", "env", "editorconfig", "gitignore", "gitattributes", "npmrc"),
            lineComments = listOf("#", "!")),

        Lang("purebasic", "PureBasic file", "PureBasic", listOf("pb", "pbi"),
            keywords = setOf("Procedure", "EndProcedure", "If", "Else", "ElseIf", "EndIf",
                "For", "Next", "While", "Wend", "Repeat", "Until", "Select", "Case",
                "EndSelect", "Define", "Global", "Protected", "Return", "True", "False",
                "Structure", "EndStructure", "Debug"),
            caseInsensitiveKeywords = true, lineComments = listOf(";")),

        Lang("python", "Python file", "Python", listOf("py", "pyw", "pyi"),
            keywords = setOf("False", "None", "True", "and", "as", "assert", "async",
                "await", "break", "class", "continue", "def", "del", "elif", "else",
                "except", "finally", "for", "from", "global", "if", "import", "in",
                "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return",
                "try", "while", "with", "yield", "self", "match", "case"),
            lineComments = listOf("#"), tripleQuotes = true),

        Lang("r", "R programming language file", "R", listOf("r"),
            keywords = setOf("function", "if", "else", "for", "while", "repeat", "break",
                "next", "return", "TRUE", "FALSE", "NULL", "NA", "Inf", "NaN", "library",
                "require", "in", "print", "cat", "source"),
            lineComments = listOf("#")),

        Lang("raku", "Raku source file", "Raku", listOf("raku", "rakumod", "rakudoc", "p6", "pm6"),
            keywords = setOf("my", "our", "sub", "method", "class", "role", "module",
                "use", "if", "elsif", "else", "unless", "for", "while", "loop", "given",
                "when", "say", "return", "True", "False", "Nil", "has", "does", "is", "grammar"),
            lineComments = listOf("#"), hashVars = true),

        Lang("rc", "Windows Resource file", "RC", listOf("rc", "rc2"),
            keywords = setOf("DIALOG", "DIALOGEX", "MENU", "MENUITEM", "POPUP", "ICON",
                "BITMAP", "STRINGTABLE", "BEGIN", "END", "CAPTION", "STYLE", "FONT",
                "PUSHBUTTON", "DEFPUSHBUTTON", "LTEXT", "RTEXT", "EDITTEXT", "COMBOBOX",
                "LISTBOX", "GROUPBOX", "CHECKBOX", "SEPARATOR"),
            caseInsensitiveKeywords = true, lineComments = listOf("//"),
            blockComments = listOf("/*" to "*/"), preprocessor = true),

        Lang("rebol", "REBOL file", "REBOL", listOf("reb", "r2", "r3"),
            keywords = setOf("func", "function", "if", "either", "while", "foreach",
                "forall", "print", "probe", "do", "make", "true", "false", "none",
                "REBOL", "to", "copy", "append", "reduce"),
            caseInsensitiveKeywords = true, lineComments = listOf(";")),

        Lang("registry", "Windows Registry file", "registry", listOf("reg"),
            keywords = setOf("dword", "hex", "REG_SZ", "REG_DWORD", "REG_BINARY",
                "REG_EXPAND_SZ", "REG_MULTI_SZ", "HKEY_LOCAL_MACHINE",
                "HKEY_CURRENT_USER", "HKEY_CLASSES_ROOT", "HKEY_USERS"),
            caseInsensitiveKeywords = true, lineComments = listOf(";"), stringDelims = listOf('"')),

        Lang("ruby", "Ruby source file", "Ruby", listOf("rb", "erb", "rake", "gemspec"),
            keywords = setOf("def", "end", "if", "elsif", "else", "unless", "while",
                "until", "for", "do", "begin", "rescue", "ensure", "class", "module",
                "return", "yield", "self", "nil", "true", "false", "and", "or", "not",
                "require", "then", "case", "when", "puts", "new", "attr_accessor",
                "attr_reader", "lambda", "proc"),
            lineComments = listOf("#"), hashVars = true),

        Lang("rust", "Rust source file", "Rust", listOf("rs"),
            keywords = setOf("as", "async", "await", "break", "const", "continue",
                "crate", "dyn", "else", "enum", "extern", "false", "fn", "for", "if",
                "impl", "in", "let", "loop", "match", "mod", "move", "mut", "pub",
                "ref", "return", "self", "Self", "static", "struct", "super", "trait",
                "true", "type", "unsafe", "use", "where", "while"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("sas", "SAS file", "SAS", listOf("sas"),
            keywords = setOf("data", "set", "run", "proc", "print", "sort", "merge",
                "by", "if", "then", "else", "do", "end", "output", "input", "datalines",
                "cards", "libname", "var", "format", "where", "keep", "drop", "quit"),
            caseInsensitiveKeywords = true, blockComments = listOf("/*" to "*/")),

        Lang("srecord", "S-Record file", "S-Record", listOf("srec", "s19", "s28", "s37", "mot"),
            stringDelims = emptyList()),

        Lang("scheme", "Scheme file", "Scheme", listOf("scm", "ss", "rkt"),
            keywords = setOf("define", "lambda", "let", "let*", "letrec", "if", "cond",
                "case", "else", "begin", "quote", "quasiquote", "set!", "car", "cdr",
                "cons", "list", "display", "and", "or", "not", "map", "apply"),
            lineComments = listOf(";")),

        Lang("shell", "Unix script file", "Shell",
            listOf("sh", "bash", "zsh", "ksh", "command", "bashrc", "profile"),
            keywords = setOf("if", "then", "else", "elif", "fi", "for", "while", "until",
                "do", "done", "case", "esac", "function", "in", "select", "time",
                "echo", "exit", "return", "break", "continue", "local", "export",
                "read", "cd", "set", "unset", "source", "alias", "shift", "trap",
                "true", "false", "printf", "eval"),
            lineComments = listOf("#"), hashVars = true),

        Lang("smalltalk", "Smalltalk file", "Smalltalk", listOf("st"),
            keywords = setOf("true", "false", "nil", "self", "super", "thisContext",
                "ifTrue", "ifFalse", "whileTrue", "whileFalse", "new", "class",
                "subclass", "instanceVariableNames", "yourself"),
            blockComments = listOf("\"" to "\""), stringDelims = listOf('\'')),

        Lang("spice", "Spice file", "Spice", listOf("cir", "spi", "sp"),
            keywords = setOf("subckt", "ends", "model", "param", "include", "lib",
                "tran", "ac", "dc", "op", "print", "plot", "end", "title", "global", "temp"),
            caseInsensitiveKeywords = true, lineComments = listOf(";"), stringDelims = emptyList()),

        Lang("sql", "Structured Query Language file", "SQL", listOf("sql"),
            keywords = setOf("select", "from", "where", "insert", "into", "values",
                "update", "set", "delete", "create", "table", "drop", "alter", "index",
                "view", "join", "inner", "left", "right", "outer", "on", "group", "by",
                "order", "having", "limit", "offset", "distinct", "as", "and", "or",
                "not", "null", "primary", "key", "foreign", "references", "union",
                "all", "exists", "between", "like", "in", "is", "int", "varchar",
                "text", "date", "default"),
            caseInsensitiveKeywords = true,
            lineComments = listOf("--"), blockComments = listOf("/*" to "*/")),

        Lang("swift", "Swift source file", "Swift", listOf("swift"),
            keywords = setOf("func", "let", "var", "class", "struct", "enum", "protocol",
                "extension", "guard", "if", "else", "for", "while", "in", "return",
                "import", "public", "private", "internal", "static", "self", "super",
                "init", "deinit", "throws", "try", "catch", "switch", "case", "default",
                "break", "continue", "true", "false", "nil", "where", "typealias",
                "associatedtype", "defer", "do", "as", "is", "some", "any"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("tcl", "Tool Command Language file", "TCL", listOf("tcl", "tk"),
            keywords = setOf("proc", "set", "if", "elseif", "else", "foreach", "for",
                "while", "switch", "return", "break", "continue", "expr", "puts",
                "global", "upvar", "namespace", "package", "source", "list", "string",
                "array", "dict", "incr", "lappend"),
            lineComments = listOf("#"), hashVars = true),

        Lang("tekhex", "Tektronix extended HEX file", "Tektronix extended HEX", listOf("tek"),
            stringDelims = emptyList()),

        Lang("tex", "TeX file", "TeX", listOf("sty", "cls", "dtx", "ins"),
            lineComments = listOf("%"), stringDelims = emptyList()),

        Lang("toml", "TOML file", "TOML", listOf("toml"),
            keywords = setOf("true", "false"),
            lineComments = listOf("#")),

        Lang("txt2tags", "txt2tags file", "txt2tags", listOf("t2t"),
            lineComments = listOf("%"), stringDelims = emptyList()),

        Lang("typescript", "TypeScript file", "TypeScript", listOf("ts", "tsx"),
            keywords = CLIKE + setOf("any", "async", "await", "boolean", "const",
                "declare", "enum", "export", "extends", "function", "implements",
                "import", "in", "instanceof", "interface", "let", "namespace", "never",
                "number", "of", "readonly", "string", "super", "type", "typeof",
                "undefined", "unknown", "var", "yield"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/"),
            stringDelims = listOf('"', '\'', '`')),

        Lang("verilog", "Verilog file", "Verilog", listOf("v", "sv", "vh", "svh"),
            keywords = setOf("module", "endmodule", "input", "output", "inout", "wire",
                "reg", "logic", "always", "assign", "begin", "end", "if", "else",
                "case", "endcase", "for", "while", "posedge", "negedge", "parameter",
                "localparam", "initial", "function", "endfunction", "task", "endtask",
                "generate", "endgenerate", "integer"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/"),
            preprocessor = true),

        Lang("vhdl", "VHSIC Hardware Description Language file", "VHDL", listOf("vhd", "vhdl"),
            keywords = setOf("entity", "architecture", "begin", "end", "process",
                "signal", "variable", "constant", "port", "map", "is", "if", "then",
                "else", "elsif", "case", "when", "others", "for", "loop", "while",
                "library", "use", "all", "std_logic", "std_logic_vector", "downto",
                "to", "in", "out", "inout", "component", "generic", "wait", "not", "and", "or"),
            caseInsensitiveKeywords = true, lineComments = listOf("--"), stringDelims = listOf('"')),

        Lang("vb", "Visual Basic file", "Visual Basic", listOf("vb", "vbs", "frm", "ctl"),
            keywords = setOf("dim", "as", "if", "then", "else", "elseif", "end", "sub",
                "function", "return", "for", "next", "each", "while", "wend", "do",
                "loop", "select", "case", "public", "private", "module", "class",
                "new", "nothing", "true", "false", "set", "let", "call", "msgbox",
                "byval", "byref", "on", "error", "resume", "exit", "and", "or", "not"),
            caseInsensitiveKeywords = true, lineComments = listOf("'")),

        Lang("visualprolog", "Visual Prolog file", "Visual Prolog", listOf("pro"),
            keywords = setOf("clauses", "predicates", "domains", "goal", "implement",
                "class", "end", "if", "then", "else", "foreach", "constants", "facts",
                "and", "or", "not", "fail", "true"),
            lineComments = listOf("%"), blockComments = listOf("/*" to "*/")),

        Lang("xml", "eXtensible Markup Language file", "XML",
            listOf("xml", "svg", "xaml", "plist", "rss", "xsl", "xslt", "xsd", "wsdl",
                "kml", "gpx", "iml", "csproj"),
            markup = true, blockComments = listOf("<!--" to "-->")),

        Lang("yaml", "YAML Ain't Markup Language file", "YAML", listOf("yaml", "yml"),
            keywords = setOf("true", "false", "null", "yes", "no", "on", "off"),
            caseInsensitiveKeywords = true, lineComments = listOf("#")),

        // ---------- extras beyond the official Windows list ----------
        Lang("kotlin", "Kotlin source file", "Kotlin", listOf("kt", "kts"),
            keywords = setOf("fun", "val", "var", "if", "else", "when", "for", "while",
                "do", "return", "object", "class", "interface", "data", "sealed",
                "enum", "companion", "override", "open", "private", "public",
                "protected", "internal", "import", "package", "is", "in", "as", "null",
                "true", "false", "this", "super", "try", "catch", "finally", "throw",
                "break", "continue", "lateinit", "by", "constructor", "init",
                "abstract", "final", "suspend", "inline", "typealias", "where", "out",
                "reified", "vararg", "get", "set"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("markdown", "Markdown file", "Markdown", listOf("md", "markdown", "mdx"),
            stringDelims = emptyList()),

        Lang("gradle", "Gradle build file", "Gradle / Groovy", listOf("gradle", "groovy", "gvy"),
            keywords = setOf("def", "if", "else", "for", "while", "return", "true",
                "false", "null", "new", "class", "import", "apply", "plugins",
                "dependencies", "implementation", "repositories", "android", "task"),
            lineComments = listOf("//"), blockComments = listOf("/*" to "*/")),

        Lang("csv", "Comma-separated values file", "CSV / TSV", listOf("csv", "tsv"),
            stringDelims = listOf('"'))
    )

    private val byKeyMap = ALL.associateBy { it.key }
    private val byExtMap: Map<String, Lang> = buildMap {
        for (l in ALL) for (e in l.exts) if (e !in this) put(e, l)
    }

    /** Exact-filename detection, mirroring the official N++ table. */
    private val byFileName: Map<String, String> = mapOf(
        "makefile" to "makefile", "gnumakefile" to "makefile",
        "cmakelists.txt" to "cmake",
        "sconstruct" to "python", "sconscript" to "python", "wscript" to "python",
        "rakefile" to "ruby", "vagrantfile" to "ruby",
        "crontab" to "shell"
    )

    val PLAINTEXT: Lang = byKeyMap.getValue("plaintext")

    fun byKey(key: String): Lang = byKeyMap[key] ?: PLAINTEXT

    /** Detection priority (per the official manual): filename, extension, shebang/prolog line. */
    fun detect(fileName: String, content: String = ""): Lang {
        val lower = fileName.lowercase()
        byFileName[lower]?.let { return byKey(it) }
        val dot = lower.lastIndexOf('.')
        val ext = if (dot >= 0) lower.substring(dot + 1) else lower
        byExtMap[ext]?.let { if (it.key != "plaintext" || ext in it.exts) return it }
        if (content.isNotEmpty()) {
            val firstLine = content.lineSequence().firstOrNull()?.trim()?.lowercase() ?: ""
            if (firstLine.startsWith("#!")) {
                return when {
                    "python" in firstLine -> byKey("python")
                    "perl" in firstLine -> byKey("perl")
                    "php" in firstLine -> byKey("php")
                    "ruby" in firstLine -> byKey("ruby")
                    "node" in firstLine -> byKey("javascript")
                    "sh" in firstLine -> byKey("shell")   // sh, bash, zsh, ksh...
                    else -> PLAINTEXT
                }
            }
            if (firstLine.startsWith("<?xml")) return byKey("xml")
            if (firstLine.startsWith("<?php")) return byKey("php")
            if (firstLine.startsWith("<!doctype html") || firstLine.startsWith("<html"))
                return byKey("html")
        }
        return PLAINTEXT
    }
}
