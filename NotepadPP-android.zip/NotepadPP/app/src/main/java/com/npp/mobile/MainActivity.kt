package com.npp.mobile

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.tabs.TabLayout
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.ArrayDeque
import java.util.regex.Pattern
import kotlin.math.max
import kotlin.math.min

class Doc(
    var name: String,
    var text: String = "",
    var uri: Uri? = null,
    var langKey: String = "plaintext",
    var dirty: Boolean = false,
    var eol: String = "LF",           // "LF" or "CRLF" (restored on save)
    var selStart: Int = 0
) {
    val undo = ArrayDeque<String>()
    val redo = ArrayDeque<String>()
}

/** Survives configuration changes (rotation, dark-mode recreate). */
object Store {
    val docs = mutableListOf<Doc>()
    var cur = -1
    var newCount = 0
}

class MainActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar
    private lateinit var tabLayout: TabLayout
    private lateinit var editor: CodeEditText
    private lateinit var statusBar: TextView
    private lateinit var hl: Highlighter

    private var suppressWatcher = false
    private var suppressTabListener = false
    private var lastUndoPush = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val highlightRunnable = Runnable { highlightNow() }
    private var bigFileWarned = false

    private var findPat = ""
    private var findRep = ""
    private var fCase = false
    private var fWhole = false
    private var fWrap = true
    private var fRegex = false

    private val prefs by lazy { getSharedPreferences("npp", Context.MODE_PRIVATE) }

    // ---------- activity result launchers ----------

    private val openDocs = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        for (u in uris) {
            persistPermission(u)
            loadUri(u)
        }
    }

    private val createDoc = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        val doc = currentDoc() ?: return@registerForActivityResult
        if (uri == null) return@registerForActivityResult
        persistPermission(uri)
        doc.uri = uri
        queryDisplayName(uri)?.let { doc.name = it }
        doc.langKey = Languages.detect(doc.name).key
        writeDoc(doc)
        refreshTabs(); syncTitle(); scheduleHighlight(0); updateStatus()
    }

    // ---------- lifecycle ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = findViewById(R.id.toolbar)
        tabLayout = findViewById(R.id.tabs)
        editor = findViewById(R.id.editor)
        statusBar = findViewById(R.id.statusBar)

        hl = Highlighter(
            kw = color(R.color.synKeyword), comment = color(R.color.synComment),
            str = color(R.color.synString), num = color(R.color.synNumber),
            meta = color(R.color.synMeta), tag = color(R.color.synTag),
            attr = color(R.color.synAttr), type = color(R.color.synType)
        )
        editor.setEditorColors(
            color(R.color.gutterBg), color(R.color.gutterFg),
            color(R.color.gutterBorder), color(R.color.caretLine)
        )
        editor.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,
            prefs.getFloat("font", 14f))
        setWrap(prefs.getBoolean("wrap", false), fromInit = true)

        toolbar.inflateMenu(R.menu.main)
        toolbar.setOnMenuItemClickListener { onMenu(it.itemId); true }
        toolbar.menu.findItem(R.id.action_wrap).isChecked = prefs.getBoolean("wrap", false)
        toolbar.menu.findItem(R.id.action_dark).isChecked =
            AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES

        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {
                if (suppressWatcher) return
                val now = System.currentTimeMillis()
                val doc = currentDoc() ?: return
                if (doc.undo.isEmpty() || now - lastUndoPush > 600) {
                    pushBounded(doc.undo, s?.toString() ?: "")
                    doc.redo.clear()
                    lastUndoPush = now
                }
            }
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressWatcher) return
                val doc = currentDoc() ?: return
                if (!doc.dirty) { doc.dirty = true; refreshTabs(); syncTitle() }
                scheduleHighlight(180)
                updateStatus()
            }
        })
        editor.onSelChanged = { _, _ -> updateStatus() }

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                if (!suppressTabListener) switchTo(tab.position)
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        statusBar.setOnClickListener { languageDialog() }

        if (Store.docs.isEmpty()) {
            if (!consumeIntent(intent)) newDoc()
        } else {
            rebuildTabsFromStore()
            switchTo(if (Store.cur in Store.docs.indices) Store.cur else 0)
            consumeIntent(intent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        consumeIntent(intent)
    }

    override fun onPause() {
        super.onPause()
        stashEditorIntoDoc()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        stashEditorIntoDoc()
        if (Store.docs.any { it.dirty }) {
            AlertDialog.Builder(this)
                .setTitle("Unsaved changes")
                .setMessage("Some tabs have unsaved changes. Leave anyway?")
                .setPositiveButton("Leave") { _, _ -> finish() }
                .setNegativeButton("Stay", null)
                .show()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    // ---------- intent handling ----------

    private fun consumeIntent(i: Intent?): Boolean {
        i ?: return false
        return when (i.action) {
            Intent.ACTION_VIEW, Intent.ACTION_EDIT -> {
                val u = i.data ?: return false
                persistPermission(u)
                loadUri(u); true
            }
            Intent.ACTION_SEND -> {
                val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return false
                Store.newCount++
                addDoc(Doc(name = "shared ${Store.newCount}.txt", text = t))
                true
            }
            else -> false
        }
    }

    private fun persistPermission(u: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                u,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Sender didn't grant persistable access; in-place save may fall back to Save As.
        }
    }

    // ---------- doc management ----------

    private fun currentDoc(): Doc? = Store.docs.getOrNull(Store.cur)

    private fun newDoc() {
        Store.newCount++
        addDoc(Doc(name = "new ${Store.newCount}", eol = "LF"))
    }

    private fun addDoc(doc: Doc) {
        stashEditorIntoDoc()
        Store.docs.add(doc)
        val tab = tabLayout.newTab()
        tabLayout.addTab(tab, false)
        attachLongPress(tab, doc)
        refreshTabs()
        switchTo(Store.docs.size - 1)
    }

    private fun rebuildTabsFromStore() {
        suppressTabListener = true
        tabLayout.removeAllTabs()
        for (d in Store.docs) {
            val tab = tabLayout.newTab()
            tabLayout.addTab(tab, false)
            attachLongPress(tab, d)
        }
        suppressTabListener = false
        refreshTabs()
    }

    private fun attachLongPress(tab: TabLayout.Tab, doc: Doc) {
        tab.view.setOnLongClickListener {
            val idx = Store.docs.indexOf(doc)
            if (idx >= 0) confirmClose(idx)
            true
        }
    }

    private fun refreshTabs() {
        suppressTabListener = true
        for (i in 0 until tabLayout.tabCount) {
            val d = Store.docs.getOrNull(i) ?: continue
            tabLayout.getTabAt(i)?.text = (if (d.dirty) "\u25CF " else "") + d.name
        }
        if (Store.cur in 0 until tabLayout.tabCount &&
            tabLayout.selectedTabPosition != Store.cur
        ) {
            tabLayout.getTabAt(Store.cur)?.select()
        }
        suppressTabListener = false
    }

    private fun stashEditorIntoDoc() {
        val doc = currentDoc() ?: return
        doc.text = editor.text?.toString() ?: ""
        doc.selStart = editor.selectionStart.coerceAtLeast(0)
    }

    private fun switchTo(index: Int) {
        if (index !in Store.docs.indices) return
        if (Store.cur != index) stashEditorIntoDoc()
        Store.cur = index
        val doc = Store.docs[index]
        suppressWatcher = true
        editor.setText(doc.text)
        val sel = min(doc.selStart, editor.length())
        editor.setSelection(sel)
        suppressWatcher = false
        bigFileWarned = false
        refreshTabs(); syncTitle(); updateStatus()
        scheduleHighlight(0)
    }

    private fun confirmClose(index: Int) {
        val doc = Store.docs.getOrNull(index) ?: return
        if (index == Store.cur) stashEditorIntoDoc()
        if (doc.dirty) {
            AlertDialog.Builder(this)
                .setTitle("Save file?")
                .setMessage("Save file \"${doc.name}\"?")
                .setPositiveButton("Yes") { _, _ ->
                    if (index != Store.cur) switchTo(index)
                    saveCurrent { closeAt(Store.cur) }
                }
                .setNegativeButton("No") { _, _ -> closeAt(index) }
                .setNeutralButton("Cancel", null)
                .show()
        } else closeAt(index)
    }

    private fun closeAt(index: Int) {
        if (index !in Store.docs.indices) return
        Store.docs.removeAt(index)
        suppressTabListener = true
        tabLayout.removeTabAt(index)
        suppressTabListener = false
        if (Store.docs.isEmpty()) { Store.cur = -1; newDoc(); return }
        val next = min(index, Store.docs.size - 1)
        Store.cur = -1
        switchTo(next)
    }

    // ---------- open / save ----------

    private fun loadUri(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: run { toast("Could not open file"); return }
            var looksBinary = false
            val head = min(bytes.size, 8192)
            for (i in 0 until head) if (bytes[i] == 0.toByte()) { looksBinary = true; break }
            if (looksBinary) toast("Looks like a binary file — opening as text anyway")
            val raw = String(bytes, Charsets.UTF_8)
            val eol = if (raw.contains("\r\n")) "CRLF" else "LF"
            val name = queryDisplayName(uri) ?: (uri.lastPathSegment ?: "untitled")
            val doc = Doc(
                name = name,
                text = raw.replace("\r\n", "\n"),
                uri = uri,
                langKey = Languages.detect(name, raw).key,
                eol = eol
            )
            addDoc(doc)
        } catch (t: Throwable) {
            toast("Open failed: ${t.message}")
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        var c: Cursor? = null
        return try {
            c = contentResolver.query(uri, null, null, null, null)
            if (c != null && c.moveToFirst()) {
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) c.getString(idx) else null
            } else null
        } catch (_: Throwable) { null } finally { c?.close() }
    }

    private fun saveCurrent(onSaved: (() -> Unit)? = null) {
        val doc = currentDoc() ?: return
        stashEditorIntoDoc()
        if (doc.uri == null) {
            pendingAfterSave = onSaved
            createDoc.launch(doc.name.ifBlank { "untitled.txt" })
        } else {
            writeDoc(doc)
            onSaved?.invoke()
        }
    }

    private var pendingAfterSave: (() -> Unit)? = null

    private fun writeDoc(doc: Doc) {
        val uri = doc.uri ?: return
        try {
            val out = doc.text.let { if (doc.eol == "CRLF") it.replace("\n", "\r\n") else it }
            contentResolver.openOutputStream(uri, "wt")?.use { os ->
                OutputStreamWriter(os, Charsets.UTF_8).use { it.write(out) }
            } ?: run { toast("Save failed (no stream)"); return }
            doc.dirty = false
            refreshTabs(); syncTitle()
            toast("Saved ${doc.name}")
            pendingAfterSave?.invoke(); pendingAfterSave = null
        } catch (t: Throwable) {
            toast("Save failed: ${t.message} — try Save As")
        }
    }

    // ---------- menu ----------

    private fun onMenu(id: Int) {
        when (id) {
            R.id.action_new -> newDoc()
            R.id.action_open -> openDocs.launch(arrayOf("*/*"))
            R.id.action_save -> saveCurrent()
            R.id.action_save_as -> {
                val doc = currentDoc() ?: return
                stashEditorIntoDoc()
                doc.uri = null
                createDoc.launch(doc.name.ifBlank { "untitled.txt" })
            }
            R.id.action_undo -> undo()
            R.id.action_redo -> redo()
            R.id.action_find -> findDialog()
            R.id.action_goto -> gotoDialog()
            R.id.action_language -> languageDialog()
            R.id.action_wrap -> {
                val item = toolbar.menu.findItem(R.id.action_wrap)
                item.isChecked = !item.isChecked
                setWrap(item.isChecked, fromInit = false)
            }
            R.id.action_zoom_in -> zoom(+1f)
            R.id.action_zoom_out -> zoom(-1f)
            R.id.action_eol -> {
                val doc = currentDoc() ?: return
                doc.eol = if (doc.eol == "CRLF") "LF" else "CRLF"
                doc.dirty = true
                refreshTabs(); syncTitle(); updateStatus()
                toast("EOL set to ${if (doc.eol == "CRLF") "Windows (CR LF)" else "Unix (LF)"}")
            }
            R.id.action_dark -> {
                stashEditorIntoDoc()
                val item = toolbar.menu.findItem(R.id.action_dark)
                item.isChecked = !item.isChecked
                AppCompatDelegate.setDefaultNightMode(
                    if (item.isChecked) AppCompatDelegate.MODE_NIGHT_YES
                    else AppCompatDelegate.MODE_NIGHT_NO
                )
            }
            R.id.action_close_tab -> if (Store.cur >= 0) confirmClose(Store.cur)
            R.id.action_close_all -> {
                stashEditorIntoDoc()
                val dirty = Store.docs.count { it.dirty }
                if (dirty > 0) {
                    AlertDialog.Builder(this)
                        .setTitle("Close all")
                        .setMessage("$dirty tab(s) have unsaved changes. Close anyway?")
                        .setPositiveButton("Close all") { _, _ -> closeAllNow() }
                        .setNegativeButton("Cancel", null)
                        .show()
                } else closeAllNow()
            }
            R.id.action_about -> aboutDialog()
        }
    }

    private fun closeAllNow() {
        Store.docs.clear()
        suppressTabListener = true
        tabLayout.removeAllTabs()
        suppressTabListener = false
        Store.cur = -1
        newDoc()
    }

    // ---------- undo / redo ----------

    private fun pushBounded(stack: ArrayDeque<String>, s: String) {
        stack.push(s)
        while (stack.size > 60) stack.removeLast()
    }

    private fun undo() {
        val doc = currentDoc() ?: return
        if (doc.undo.isEmpty()) { toast("Nothing to undo"); return }
        pushBounded(doc.redo, editor.text?.toString() ?: "")
        applySnapshot(doc.undo.pop())
    }

    private fun redo() {
        val doc = currentDoc() ?: return
        if (doc.redo.isEmpty()) { toast("Nothing to redo"); return }
        pushBounded(doc.undo, editor.text?.toString() ?: "")
        applySnapshot(doc.redo.pop())
    }

    private fun applySnapshot(s: String) {
        val doc = currentDoc() ?: return
        suppressWatcher = true
        editor.setText(s)
        editor.setSelection(min(s.length, editor.length()))
        suppressWatcher = false
        doc.text = s
        doc.dirty = true
        refreshTabs(); syncTitle(); updateStatus()
        scheduleHighlight(0)
    }

    // ---------- highlighting ----------

    private fun scheduleHighlight(delayMs: Long) {
        handler.removeCallbacks(highlightRunnable)
        handler.postDelayed(highlightRunnable, delayMs)
    }

    private fun highlightNow() {
        val doc = currentDoc() ?: return
        val e = editor.text ?: return
        if (e.length > Highlighter.MAX_HIGHLIGHT_CHARS) {
            if (!bigFileWarned) {
                bigFileWarned = true
                toast("Large file — highlighting off for speed")
            }
            hl.clear(e)
            return
        }
        suppressWatcher = true
        try {
            hl.highlight(e, Languages.byKey(doc.langKey))
        } finally {
            suppressWatcher = false
        }
    }

    // ---------- view options ----------

    private fun setWrap(on: Boolean, fromInit: Boolean) {
        editor.setHorizontallyScrolling(!on)
        if (!fromInit) {
            prefs.edit().putBoolean("wrap", on).apply()
            editor.invalidate()
            editor.requestLayout()
        }
    }

    private fun zoom(delta: Float) {
        val cur = editor.textSize / resources.displayMetrics.scaledDensity
        val next = (cur + delta).coerceIn(8f, 32f)
        editor.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, next)
        prefs.edit().putFloat("font", next).apply()
    }

    // ---------- status / title ----------

    private fun syncTitle() {
        val doc = currentDoc()
        toolbar.title =
            if (doc == null) "Notepad++"
            else (if (doc.dirty) "*" else "") + doc.name + " - Notepad++"
    }

    @SuppressLint("SetTextI18n")
    private fun updateStatus() {
        val doc = currentDoc() ?: return
        val t = editor.text?.toString() ?: ""
        val selS = max(0, editor.selectionStart)
        val selE = max(0, editor.selectionEnd)
        val pos = min(selS, selE)
        var ln = 1
        var lastNl = -1
        for (i in 0 until min(pos, t.length)) if (t[i] == '\n') { ln++; lastNl = i }
        val col = pos - lastNl
        val selChars = kotlin.math.abs(selE - selS)
        val selLines = if (selChars == 0) 0
        else t.substring(min(selS, selE), min(max(selS, selE), t.length)).count { it == '\n' } + 1
        val lines = t.count { it == '\n' } + 1
        val lang = Languages.byKey(doc.langKey)
        val eolLabel = if (doc.eol == "CRLF") "Windows (CR LF)" else "Unix (LF)"
        statusBar.text =
            "Ln : $ln  Col : $col  Sel : $selChars | $selLines" +
            "    length : ${t.length}  lines : $lines" +
            "    ${lang.label}    $eolLabel    UTF-8"
    }

    // ---------- dialogs ----------

    private fun languageDialog() {
        val doc = currentDoc() ?: return
        val items = Languages.ALL.sortedBy { it.menu.lowercase() }
        val names = items.map { it.menu }.toTypedArray()
        val curIdx = items.indexOfFirst { it.key == doc.langKey }
        AlertDialog.Builder(this)
            .setTitle("Language")
            .setSingleChoiceItems(names, curIdx) { d, which ->
                doc.langKey = items[which].key
                updateStatus(); scheduleHighlight(0)
                d.dismiss()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun gotoDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Line number"
        }
        AlertDialog.Builder(this)
            .setTitle("Go To…")
            .setView(input)
            .setPositiveButton("Go") { _, _ ->
                val n = input.text.toString().toIntOrNull() ?: return@setPositiveButton
                gotoLine(n)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun gotoLine(n: Int) {
        val t = editor.text?.toString() ?: return
        var line = 1
        var idx = 0
        while (line < n && idx < t.length) {
            val nl = t.indexOf('\n', idx)
            if (nl < 0) break
            idx = nl + 1
            line++
        }
        editor.requestFocus()
        editor.setSelection(min(idx, t.length))
        editor.post { editor.bringPointIntoView(min(idx, editor.length())) }
    }

    @SuppressLint("InflateParams")
    private fun findDialog() {
        val v = layoutInflater.inflate(R.layout.dialog_find, null)
        val fIn = v.findViewById<EditText>(R.id.findInput)
        val rIn = v.findViewById<EditText>(R.id.replaceInput)
        val ckWhole = v.findViewById<CheckBox>(R.id.ckWhole)
        val ckCase = v.findViewById<CheckBox>(R.id.ckCase)
        val ckWrap = v.findViewById<CheckBox>(R.id.ckWrap)
        val ckRegex = v.findViewById<CheckBox>(R.id.ckRegex)
        val msg = v.findViewById<TextView>(R.id.findMsg)

        val sel = editor.text?.toString()
            ?.substring(
                max(0, min(editor.selectionStart, editor.selectionEnd)),
                max(0, max(editor.selectionStart, editor.selectionEnd))
            ) ?: ""
        if (sel.isNotEmpty() && !sel.contains('\n')) findPat = sel
        fIn.setText(findPat); rIn.setText(findRep)
        ckWhole.isChecked = fWhole; ckCase.isChecked = fCase
        ckWrap.isChecked = fWrap; ckRegex.isChecked = fRegex

        val dlg = AlertDialog.Builder(this)
            .setTitle("Find / Replace")
            .setView(v)
            .create()

        fun readUi() {
            findPat = fIn.text.toString()
            findRep = rIn.text.toString()
            fWhole = ckWhole.isChecked; fCase = ckCase.isChecked
            fWrap = ckWrap.isChecked; fRegex = ckRegex.isChecked
        }
        fun show(m: String, err: Boolean = false) {
            msg.text = m
            msg.setTextColor(if (err) 0xFFCC0000.toInt() else color(R.color.synComment))
        }

        v.findViewById<View>(R.id.btnNext).setOnClickListener {
            readUi(); if (!findStep(true)) show("Can't find \"$findPat\"", true) else show("")
        }
        v.findViewById<View>(R.id.btnPrev).setOnClickListener {
            readUi(); if (!findStep(false)) show("Can't find \"$findPat\"", true) else show("")
        }
        v.findViewById<View>(R.id.btnCount).setOnClickListener {
            readUi()
            val p = buildPattern() ?: run { show("Invalid regular expression", true); return@setOnClickListener }
            var n = 0
            val m = p.matcher(editor.text?.toString() ?: "")
            while (m.find()) n++
            show("Count: $n match${if (n == 1) "" else "es"}")
        }
        v.findViewById<View>(R.id.btnReplace).setOnClickListener {
            readUi()
            when (replaceOne()) {
                null -> show("Invalid regular expression", true)
                false -> show("Can't find \"$findPat\"", true)
                true -> show("")
            }
        }
        v.findViewById<View>(R.id.btnReplaceAll).setOnClickListener {
            readUi()
            val n = replaceAll()
            if (n == null) show("Invalid regular expression", true)
            else show("Replace All: $n occurrence${if (n == 1) "" else "s"} replaced")
        }
        v.findViewById<View>(R.id.btnCloseFind).setOnClickListener { dlg.dismiss() }
        dlg.show()
    }

    private fun buildPattern(): Pattern? {
        if (findPat.isEmpty()) return null
        var src = if (fRegex) findPat else Pattern.quote(findPat)
        if (fWhole) src = "\\b$src\\b"
        var flags = Pattern.MULTILINE
        if (!fCase) flags = flags or Pattern.CASE_INSENSITIVE
        return try { Pattern.compile(src, flags) } catch (_: Throwable) { null }
    }

    private fun findStep(forward: Boolean): Boolean {
        val p = buildPattern() ?: return false
        val t = editor.text?.toString() ?: return false
        val selS = max(0, min(editor.selectionStart, editor.selectionEnd))
        val selE = max(0, max(editor.selectionStart, editor.selectionEnd))
        val m = p.matcher(t)

        fun selectMatch(s: Int, e: Int): Boolean {
            editor.requestFocus()
            editor.setSelection(s, e)
            editor.post { editor.bringPointIntoView(s) }
            return true
        }

        if (forward) {
            if (m.find(min(selE, t.length))) return selectMatch(m.start(), m.end())
            if (fWrap && m.find(0)) return selectMatch(m.start(), m.end())
            return false
        } else {
            var ls = -1; var le = -1
            while (m.find()) {
                if (m.start() >= selS) break
                ls = m.start(); le = m.end()
            }
            if (ls >= 0) return selectMatch(ls, le)
            if (fWrap) {
                val m2 = p.matcher(t)
                var s2 = -1; var e2 = -1
                while (m2.find()) { s2 = m2.start(); e2 = m2.end() }
                if (s2 >= 0) return selectMatch(s2, e2)
            }
            return false
        }
    }

    /** true = replaced/moved, false = not found, null = bad pattern */
    private fun replaceOne(): Boolean? {
        val p = buildPattern() ?: return null
        val t = editor.text?.toString() ?: return false
        val selS = max(0, min(editor.selectionStart, editor.selectionEnd))
        val selE = max(0, max(editor.selectionStart, editor.selectionEnd))
        if (selE > selS) {
            val selected = t.substring(selS, min(selE, t.length))
            val whole = p.matcher(selected)
            if (whole.matches()) {
                val replacement =
                    if (fRegex) {
                        try { p.matcher(selected).replaceFirst(findRep) }
                        catch (_: Throwable) { return null }
                    } else findRep
                editor.text?.replace(selS, selE, replacement)
                editor.setSelection(min(selS + replacement.length, editor.length()))
            }
        }
        return findStep(true)
    }

    /** count replaced, or null on bad pattern */
    private fun replaceAll(): Int? {
        val p = buildPattern() ?: return null
        val t = editor.text?.toString() ?: return 0
        val m = p.matcher(t)
        var n = 0
        while (m.find()) n++
        if (n == 0) return 0
        val out = try {
            if (fRegex) p.matcher(t).replaceAll(findRep)
            else p.matcher(t).replaceAll(java.util.regex.Matcher.quoteReplacement(findRep))
        } catch (_: Throwable) { return null }
        suppressWatcher = true
        val doc = currentDoc()
        doc?.let { pushBounded(it.undo, t); it.redo.clear() }
        editor.setText(out)
        editor.setSelection(min(out.length, editor.length()))
        suppressWatcher = false
        doc?.let { it.text = out; it.dirty = true }
        refreshTabs(); syncTitle(); updateStatus()
        scheduleHighlight(0)
        return n
    }

    private fun aboutDialog() {
        AlertDialog.Builder(this)
            .setTitle("About Notepad++")
            .setMessage(
                "Notepad++ for Android — unofficial homage, v4.\n\n" +
                "The original Notepad++ by Don Ho is a free, open-source (GPL) " +
                "editor for Windows only. Its official built-in list covers 93 " +
                "languages; this app recognizes ${Languages.ALL.size - 1} — every " +
                "one of theirs plus Kotlin, Markdown, Gradle and CSV — and reads/" +
                "writes any file of any type, saving in place.\n\n" +
                "Long-press a tab to close it. Tap the status bar to change language."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------- misc ----------

    private fun color(id: Int) = ContextCompat.getColor(this, id)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
