package com.npp.mobile

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.util.TypedValue
import androidx.appcompat.widget.AppCompatEditText
import kotlin.math.max
import kotlin.math.min

/**
 * EditText with a Scintilla-style line-number gutter and current-line highlight.
 * The gutter stays pinned while scrolling horizontally (word wrap off).
 */
class CodeEditText @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : AppCompatEditText(context, attrs) {

    var onSelChanged: ((Int, Int) -> Unit)? = null

    private val gutterPaint = Paint()
    private val borderPaint = Paint()
    private val caretLinePaint = Paint()
    private val numPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textAlign = Paint.Align.RIGHT
    }

    private var gutterWidth = 0
    private var lastDigits = 0
    private val innerPad = dp(6f)
    private val textPad = dp(8f)

    /** Offsets of every '\n', kept sorted; rebuilt lazily for numbering wrapped lines. */
    private var newlineIndex = IntArray(0)
    private var indexDirty = true

    init {
        typeface = Typeface.MONOSPACE
        setHorizontallyScrolling(true)
        isVerticalScrollBarEnabled = true
        includeFontPadding = false
    }

    fun setEditorColors(gutterBg: Int, gutterFg: Int, gutterBorder: Int, caretLine: Int) {
        gutterPaint.color = gutterBg
        numPaint.color = gutterFg
        borderPaint.color = gutterBorder
        borderPaint.strokeWidth = dp(1f).toFloat()
        caretLinePaint.color = caretLine
        invalidate()
    }

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        onSelChanged?.invoke(selStart, selEnd)
        invalidate()
    }

    override fun onTextChanged(text: CharSequence?, start: Int, before: Int, count: Int) {
        super.onTextChanged(text, start, before, count)
        indexDirty = true
    }

    override fun setTextSize(unit: Int, size: Float) {
        super.setTextSize(unit, size)
        lastDigits = 0 // force gutter re-measure
    }

    private fun rebuildIndexIfNeeded() {
        if (!indexDirty) return
        val t = text ?: return
        var n = 0
        for (i in t.indices) if (t[i] == '\n') n++
        val arr = IntArray(n)
        var j = 0
        for (i in t.indices) if (t[i] == '\n') { arr[j++] = i }
        newlineIndex = arr
        indexDirty = false
    }

    /** 1-based text-line number for a character offset. */
    private fun lineNumberFor(offset: Int): Int {
        val arr = newlineIndex
        var lo = 0; var hi = arr.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (arr[mid] < offset) lo = mid + 1 else hi = mid
        }
        return lo + 1
    }

    private fun ensureGutter(totalLines: Int) {
        val digits = max(2, totalLines.toString().length)
        if (digits == lastDigits) return
        lastDigits = digits
        numPaint.textSize = textSize * 0.85f
        gutterWidth = (numPaint.measureText("0") * digits + innerPad * 2).toInt()
        val gw = gutterWidth
        post { setPadding(gw + textPad, textPad, textPad, textPad) }
    }

    override fun onDraw(canvas: Canvas) {
        val layout = layout
        if (layout == null) { super.onDraw(canvas); return }

        rebuildIndexIfNeeded()
        val totalTextLines = newlineIndex.size + 1
        ensureGutter(totalTextLines)

        val sx = scrollX
        val sy = scrollY
        val visTop = sy
        val visBottom = sy + height

        // current-line highlight (only when there is no range selection)
        val selS = selectionStart
        if (selS >= 0 && selS == selectionEnd) {
            val vLine = layout.getLineForOffset(min(selS, layout.text.length))
            val top = layout.getLineTop(vLine) + paddingTop
            val bottom = layout.getLineBottom(vLine) + paddingTop
            canvas.drawRect(
                sx.toFloat(), top.toFloat(),
                (sx + width).toFloat(), bottom.toFloat(), caretLinePaint
            )
        }

        // gutter background + border, pinned to the left edge
        canvas.drawRect(
            sx.toFloat(), visTop.toFloat(),
            (sx + gutterWidth).toFloat(), visBottom.toFloat(), gutterPaint
        )
        canvas.drawLine(
            (sx + gutterWidth).toFloat(), visTop.toFloat(),
            (sx + gutterWidth).toFloat(), visBottom.toFloat(), borderPaint
        )

        // visible line numbers (numbered per text line, not per wrapped line)
        val first = layout.getLineForVertical(max(0, visTop - paddingTop))
        val last = layout.getLineForVertical(max(0, visBottom - paddingTop))
        val t = text
        val numX = (sx + gutterWidth - innerPad).toFloat()
        for (i in first..min(last, layout.lineCount - 1)) {
            val start = layout.getLineStart(i)
            val firstOfTextLine = start == 0 || (t != null && start - 1 < t.length && t[start - 1] == '\n')
            if (!firstOfTextLine) continue
            val n = lineNumberFor(start)
            val base = (layout.getLineBaseline(i) + paddingTop).toFloat()
            canvas.drawText(n.toString(), numX, base, numPaint)
        }

        super.onDraw(canvas)
    }

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()
}
