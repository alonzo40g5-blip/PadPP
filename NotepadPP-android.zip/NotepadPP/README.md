# Notepad++ for Android (unofficial) — v4, native Kotlin

A native Android recreation of the Windows Notepad++ editing experience.
Not affiliated with the official Notepad++ project (which is Windows-only, by Don Ho).

## What it does

- **Opens everything.** The Open button uses the system file picker with `*/*`,
  so any file can be selected — `.kt`, `.sh`, `.bash`, `.html`, `.py`, `.sql`,
  `.yml`, `.ini`, config files with no extension, all of it. Unknown types open
  as plain text. It also registers as an **"Open with"** target, so tapping a
  text/code file in a file manager, Downloads, or a mail attachment offers
  Notepad++.
- **Saves in place.** Files opened through the picker or "Open with" are written
  back to their original location (Storage Access Framework, persisted
  permission). New files use Save As via the system dialog.
- **97 languages — more than the Windows original.** The official Notepad++
  built-in list (npp-user-manual.org/docs/programing-languages/) has 93
  languages. This app recognizes all 93 of them (from ActionScript, Ada and
  Assembly through Verilog, VHDL, Visual Basic, XML and YAML — including the
  exotic ones like BaanC, Csound, MMIXAL, Intel HEX / S-Record / Tektronix HEX,
  ErrorList, txt2tags) **plus 4 more: Kotlin, Markdown, Gradle/Groovy and CSV**,
  across 240 file extensions. Language detection follows the official rules:
  extension, then special filenames (makefile, CMakeLists.txt, Rakefile,
  crontab…), then shebang / prolog lines (#!/bin/bash, <?php, <?xml…).
- **Editor:** tabs with the modified-dot indicator and long-press-to-close,
  line-number gutter that stays pinned while scrolling sideways, current-line
  highlight, classic Notepad++ palette (keywords blue/bold, comments green,
  strings gray, numbers orange), with special renderers for Diff, LaTeX/TeX,
  ANSI/ErrorList logs, HEX record files, search results and Markdown.
- **Tools:** Find/Replace dialog (match case, whole word, wrap around, regex,
  Count, Replace All), Go to line, undo/redo, word wrap, zoom, CRLF/LF
  conversion, dark mode, shared-text receiving ("Share to Notepad++").
- Status bar in the Windows style: `Ln / Col / Sel · length / lines · language ·
  EOL · UTF-8`. Tap it to switch language.

## Build it on GitHub — no Android Studio needed (about 5 minutes)

1. Create a new GitHub repository (private is fine).
2. Upload the **contents** of this NotepadPP folder — `settings.gradle.kts`,
   `app/`, `.github/`, etc. must end up at the **top level** of the repo.
   (The workflow also tolerates one `NotepadPP/` subfolder, but the `.github`
   folder itself must be at the repo root for Actions to see it.)
3. Open the repo's **Actions** tab — the "Build APK" workflow starts on its
   own (click "I understand… enable them" if GitHub asks). It takes ~3-5 min.
4. Open the finished run → **Artifacts** → download **NotepadPP-debug-apk**,
   unzip it, copy `app-debug.apk` to your phone and install it
   (allow "install unknown apps" when prompted).

Every future push rebuilds the APK automatically. You can also start a build
by hand: Actions → Build APK → Run workflow.

## Or build locally in Android Studio (about 10 minutes)

1. Install **Android Studio** (any recent version; it bundles the JDK/SDK).
2. **File → Open** and select this folder (`NotepadPP`). Let Gradle sync —
   Studio will download Gradle 8.9 and dependencies automatically. If it asks
   about a missing Gradle wrapper, accept the recommended version.
3. Plug in your phone with **USB debugging** enabled (Settings → Developer
   options) and press **Run ▶** — the app installs and launches.
   - Or **Build → Build App Bundle(s)/APK(s) → Build APK(s)**, then copy
     `app/build/outputs/apk/debug/app-debug.apk` to the phone and install it
     (allow "install unknown apps" when prompted).

Requirements: Android 8.0 (API 26) or newer.

App version: 4.0.

## Notes and honest limits

- Files are read/written as UTF-8. Other encodings load as best-effort text.
- Very large files (over ~250k characters) open fine but highlighting switches
  off for speed.
- No plugins/macros — those are Windows Notepad++ subsystems.
- The name and look are an homage for personal use; rename the app
  (`res/values/strings.xml` and `applicationId`) before distributing anywhere.

## Project layout

```
app/src/main/java/com/npp/mobile/
  MainActivity.kt   — tabs, open/save (SAF), find/replace, menus, status bar
  CodeEditText.kt   — editor view: gutter, line numbers, caret-line highlight
  Highlighter.kt    — span-based syntax highlighter (N++ colors)
  Languages.kt      — language table + extension map
app/src/main/res/   — layouts, menu, day/night colors, icons
```
